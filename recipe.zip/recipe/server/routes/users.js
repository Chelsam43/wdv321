// server/routes/users.js
const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../database');

const router = express.Router();
const saltRounds = 10;

// REGISTER a new user
router.post('/register', async (req, res) => {
  const { username, password, email, pin } = req.body;

  if (!username || !password || !email || !pin) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  const hashedPassword = await bcrypt.hash(password, saltRounds);
  const hashedPin = await bcrypt.hash(pin.toString(), saltRounds);

  const sql = `INSERT INTO users (username, password, email, pin) VALUES (?, ?, ?, ?)`;
  console.log("Inserting user into database:", username);
  db.run(sql, [username, hashedPassword, email, hashedPin], function (err) {
    if (err) {
      if (err.message.includes('UNIQUE')) {
        return res.status(409).json({ message: 'Username already exists' });
      }
      return res.status(500).json({ message: 'Error saving user', error: err.message });
    }

    res.status(201).json({ message: 'User registered successfully' });
  });
});

// LOGIN
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  db.get(`SELECT * FROM users WHERE username = ?`, [username], async (err, user) => {
    if (err || !user) return res.status(401).json({ message: 'Invalid credentials' });

    const match = await bcrypt.compare(password, user.password);
    if (match) {
      res.json({ message: 'Login successful', user: { username: user.username, email: user.email } });
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  });
});

// PASSWORD RESET (PIN Verification)
router.post('/reset-password', (req, res) => {
  const { username, pin, newPassword } = req.body;

  db.get(`SELECT * FROM users WHERE username = ?`, [username], async (err, user) => {
    if (err || !user) return res.status(404).json({ message: 'User not found' });

    const pinMatch = await bcrypt.compare(pin.toString(), user.pin);
    if (!pinMatch) return res.status(403).json({ message: 'Invalid PIN' });

    const hashedNewPassword = await bcrypt.hash(newPassword, saltRounds);
    db.run(`UPDATE users SET password = ? WHERE username = ?`, [hashedNewPassword, username], function (err) {
      if (err) return res.status(500).json({ message: 'Failed to reset password' });
      res.json({ message: 'Password reset successful' });
    });
  });
});

module.exports = router;