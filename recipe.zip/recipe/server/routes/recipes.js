const express = require('express');
const router = express.Router();
const db = require('../database');
const multer = require('multer');//image upload
const path = require('path');

// Multer setup for image upload
const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
const upload = multer({ storage: storage });

// Get all recipes
router.get('/', (req, res) => {
  db.all('SELECT * FROM recipes', [], (err, rows) => {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ error: 'Failed to retrieve recipes' });
    }
    // Parse tags and ingredients from TEXT into arrays
    const recipes = rows.map(r => ({
      ...r,
      tags: r.tags ? JSON.parse(r.tags) : [],
      ingredients: r.ingredients ? JSON.parse(r.ingredients) : []
    }));
    res.json(recipes);
  });
});

// Create new recipe
router.post('/', upload.single('image'), (req, res) => {
  const {
    id, username, title, servings, mealType, difficulty, instructions, notes, isPublic, tags, ingredients
  } = req.body;

  const parsedTags = typeof tags === 'string' ? JSON.parse(tags) : (tags || []);
  const parsedIngredients = typeof ingredients === 'string' ? JSON.parse(ingredients) : (ingredients || []);

  const imagePath = req.file ? `/uploads/${req.file.filename}` : '';

  db.run(`
    INSERT INTO recipes (id, username, title, servings, mealType, difficulty, instructions, notes, isPublic, tags, ingredients, image)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    id,
    username,
    title,
    servings,
    mealType,
    difficulty,
    instructions,
    notes,
    isPublic ? 1 : 0,
    JSON.stringify(parsedTags),
    JSON.stringify(parsedIngredients),
    imagePath
  ], function(err) {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ error: 'Failed to save recipe' });
    }
    res.json({ message: 'Recipe saved successfully!' });
  });
});

// Update existing recipe
router.put('/:id', upload.single('image'), (req, res) => {
  const {
    username, title, servings, mealType, difficulty, instructions, notes, isPublic, tags, ingredients
  } = req.body;

  const parsedTags = typeof tags === 'string' ? JSON.parse(tags) : (tags || []);
  const parsedIngredients = typeof ingredients === 'string' ? JSON.parse(ingredients) : (ingredients || []);

  const imagePath = req.file ? `/uploads/${req.file.filename}` : req.body.existingImage;

  const recipeId = req.params.id;
  db.get('SELECT * FROM recipes WHERE id = ?', [recipeId], (err, recipe) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to retrieve recipe for update' });
    }
    if (!recipe || recipe.username !== username) {
      return res.status(403).json({ error: 'You are not authorized to update this recipe' });
    }

    db.run(`
      UPDATE recipes
      SET title = ?, servings = ?, mealType = ?, difficulty = ?, instructions = ?, notes = ?, isPublic = ?, tags = ?, ingredients = ?, image = ?
      WHERE id = ?
    `, [
      title,
      servings,
      mealType,
      difficulty,
      instructions,
      notes,
      isPublic ? 1 : 0,
      JSON.stringify(parsedTags),
      JSON.stringify(parsedIngredients),
      imagePath,
      recipeId
    ], function(err) {
      if (err) {
        console.error(err.message);
        return res.status(500).json({ error: 'Failed to update recipe' });
      }
      res.json({ message: 'Recipe updated successfully!' });
    });
  });
});


// Update recipe
router.put('/:id', upload.single('image'), (req, res) => {
  const {
    title, servings, mealType, difficulty, instructions, notes, isPublic, tags, ingredients
  } = req.body;
  const imagePath = req.file ? `/uploads/${req.file.filename}` : req.body.existingImage;

  const recipeId = req.params.id;
  db.get('SELECT * FROM recipes WHERE id = ?', [recipeId], (err, recipe) => {
    if (err) {
      return res.status(500).json({ error: 'Failed to retrieve recipe for update' });
    }
    if (!recipe || recipe.username !== req.body.username) {
      return res.status(403).json({ error: 'You are not authorized to update this recipe' });
    }


  db.run(`
    UPDATE recipes
    SET title = ?, servings = ?, mealType = ?, difficulty = ?, instructions = ?, notes = ?, isPublic = ?, tags = ?, ingredients = ?, image = ?
    WHERE id = ?
  `, [
    title,
    servings,
    mealType,
    difficulty,
    instructions,
    notes,
    isPublic ? 1 : 0,
    JSON.stringify(tags || []),
    JSON.stringify(ingredients || []),
    imagePath,
    req.params.id
  ], function(err) {
    if (err) {
      console.error(err.message);
      return res.status(500).json({ error: 'Failed to update recipe' });
    }
    res.json({ message: 'Recipe updated successfully!' });
  });
});
});
module.exports = router;