const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors'); 

const db = require('./database');
const userRoutes = require('./routes/users');

const app = express();
const PORT = 3000;


app.use(cors());
app.use(bodyParser.json());
app.use('/api/users', userRoutes);

app.get('/', (req, res) => {
  res.send('Server is running!');
});

app.listen(PORT, () => {
  console.log(`Server listening at http://localhost:${PORT}`);
});
