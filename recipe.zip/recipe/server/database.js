// server/database.js
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, 'db', 'recipeManager.db');
const db = new sqlite3.Database(dbPath);

console.log("Using database at:", dbPath);

// Create user table if it doesn't exist
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      password TEXT NOT NULL,
      email TEXT NOT NULL,
      pin TEXT NOT NULL
    )
  `);
});

module.exports = db;