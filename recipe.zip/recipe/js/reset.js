// Handle PIN-based password reset
document.getElementById("pinResetForm").addEventListener("submit", async (e) => {
    e.preventDefault();
  
    const username = document.getElementById("fpUsername").value;
    const pin = document.getElementById("fpPin").value;
    const newPassword = document.getElementById("fpNewPassword").value;
  
    try {
      const response = await fetch("http://localhost:3000/api/users/reset-password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ username, pin, newPassword })
      });
  
      const data = await response.json();
  
      if (response.ok) {
        alert(data.message);
        setTimeout(() => {
          window.location.href = "index.html";
        }, 0);
      } else {
        alert("Error: " + data.message);
      }
    } catch (error) {
      console.error("Fetch error:", error);
      alert("Something went wrong: " + error.message);
    }
  });
  
  
  document.getElementById("returnToLoginBtn")?.addEventListener("click", () => {
    window.location.href = "index.html";
  });