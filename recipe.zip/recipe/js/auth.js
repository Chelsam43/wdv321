document.getElementById("loginForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();
  
    const usernameInput = document.getElementById("loginUsername");
    const passwordInput = document.getElementById("loginPassword");
  
    const username = usernameInput.value;
    const password = passwordInput.value;
  
    try {
      const response = await fetch("http://localhost:3000/api/users/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ username, password })
      });
  
      const data = await response.json();
  
      if (response.ok) {
        alert("Login successful!");
        localStorage.setItem("loggedInUser", JSON.stringify(data.user));
        window.location.href = "member.html";
      } else {
        alert("Login failed: " + data.message);
  
        //  Clear inputs if login fails
        usernameInput.value = "";
        passwordInput.value = "";
      }
    } catch (err) {
      console.error("Login error:", err);
      alert("Something went wrong.");
  
      // Clear inputs if there's a network error
      usernameInput.value = "";
      passwordInput.value = "";
    }
});

document.getElementById("registerForm")?.addEventListener("submit", async (e) => {
    e.preventDefault();
  
    const usernameInput = document.getElementById("registerUsername");
    const emailInput = document.querySelector("input[name='newEmail']");
    const passwordInput = document.querySelector("input[name='newPassword']");
    const pinInput = document.querySelector("input[name='securityPin']");
  
    if (!usernameInput || !emailInput || !passwordInput || !pinInput) {
      alert("Form elements are missing.");
      return;
    }
  
    const username = usernameInput.value;
    const email = emailInput.value;
    const password = passwordInput.value;
    const pin = pinInput.value;
  
    try {
      const response = await fetch("http://localhost:3000/api/users/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ username, password, email, pin })
      });
  
      const data = await response.json();
  
      if (response.ok) {
        alert("Registration successful! Please log in.");
        document.getElementById("registerForm").reset();
      } else {
        alert("Registration failed: " + data.message);
      }
    } catch (err) {
      console.error("Registration error:", err);
      alert("Something went wrong during registration.");
    }
  });
 