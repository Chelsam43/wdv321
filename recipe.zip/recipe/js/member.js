window.onload = () => {
    const user = JSON.parse(localStorage.getItem("loggedInUser"));
    if (!user) {
      alert("You must be logged in to view this page.");
      window.location.href = "index.html";
      return;
    }
  
    document.getElementById("welcomeMessage").textContent = `Welcome, ${user.username}!`;
  
    document.getElementById("logoutBtn").addEventListener("click", () => {
      localStorage.removeItem("loggedInUser");
      window.location.href = "index.html";
    });
  
    document.getElementById("cancelEditBtn").addEventListener("click", () => {
      document.getElementById("recipeForm").reset();
      document.getElementById("ingredientsContainer").innerHTML = "";
      tagList.innerHTML = "";
      tags.length = 0;
      document.getElementById("editingId").value = "";
      document.getElementById("cancelEditBtn").style.display = "none";
      addIngredientRow();
    });
  
    addIngredientRow();
    loadUserRecipes();
  
    document.getElementById("filterMeal").addEventListener("change", loadUserRecipes);
    document.getElementById("filterDifficulty").addEventListener("change", loadUserRecipes);
    document.getElementById("sortOption").addEventListener("change", loadUserRecipes);
    document.getElementById("sortDirection").addEventListener("change", loadUserRecipes);
  };
  
  function debounce(fn, delay) {
    let timer;
    return function () {
      clearTimeout(timer);
      timer = setTimeout(() => fn.apply(this, arguments), delay);
    };
  }
  
  function addIngredientRow() {
    const container = document.getElementById("ingredientsContainer");
    const row = document.createElement("div");
    row.innerHTML = `
      <input type="text" placeholder="Amount" class="ingredientAmount" required />
      <input type="text" placeholder="Unit" class="ingredientUnit" required />
      <input type="text" placeholder="Ingredient Name" class="ingredientName" required />
      <button type="button" onclick="this.parentElement.remove()">Remove</button><br>
    `;
    container.appendChild(row);
  }

  function resetForm() {
    document.getElementById("recipeForm").reset();
    document.getElementById("ingredientsContainer").innerHTML = "";
    document.getElementById("editingId").value = "";
    tagList.innerHTML = "";
    tags.length = 0;
    addIngredientRow();
  }
  
  const tags = [];
  const tagInput = document.getElementById("tagInput");
  const tagList = document.getElementById("tagList");
  tagInput?.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && this.value.trim()) {
      e.preventDefault();
      const rawTag = this.value.trim();
      const cleanedTag = rawTag.replace(/^#/, "");
      tags.push(cleanedTag);
      const li = document.createElement("li");
      li.textContent = `#${cleanedTag}`;
      li.onclick = () => {
        tags.splice(tags.indexOf(cleanedTag), 1);
        li.remove();
      };
      tagList.appendChild(li);
      this.value = "";
    }
  });
  
  async function loadUserRecipes() {
    const user = JSON.parse(localStorage.getItem("loggedInUser"));
    const container = document.getElementById("memberRecipeList");
    const mealFilter = document.getElementById("filterMeal").value;
    const difficultyFilter = document.getElementById("filterDifficulty").value;
    const sortOption = document.getElementById("sortOption").value;
    const sortDir = document.getElementById("sortDirection").value;
  
    try {
      const response = await fetch("http://localhost:3000/api/recipes");
      const recipes = await response.json();
  
      let filtered = recipes.filter(r => r.username === user.username);
      if (mealFilter) filtered = filtered.filter(r => r.mealType === mealFilter);
      if (difficultyFilter) filtered = filtered.filter(r => r.difficulty === difficultyFilter);
  
      filtered.sort((a, b) => {
        const valA = (a[sortOption] || "").toString().toLowerCase();
        const valB = (b[sortOption] || "").toString().toLowerCase();
        return sortDir === "asc" ? valA.localeCompare(valB) : valB.localeCompare(valA);
      });
  
      container.innerHTML = filtered.map(recipe => {
        const tagsArray = Array.isArray(recipe.tags) ? recipe.tags : JSON.parse(recipe.tags || "[]");
        const ingredientsArray = Array.isArray(recipe.ingredients) ? recipe.ingredients : JSON.parse(recipe.ingredients || "[]");
        const tagChips = tagsArray.map(tag => `<span class="tag-chip">#${tag}</span>`).join(" ");
        const fullId = `full-${recipe.id}`;
        const ingId = `ingredients-${recipe.id}`;
  
        return `
          <div class="recipe-card">
            <h4>${recipe.title}</h4>
            ${recipe.isPublic ? "<span class='label-public'>Public</span>" : "<span class='label-private'>Private</span>"}
            ${recipe.image ? `<img src="http://localhost:3000${recipe.image}" alt="${recipe.title}" class="recipe-img" />` : ""}
            <p><strong>Servings:</strong> ${parseInt(recipe.servings)}</p>
            <p><strong>Meal Type:</strong> ${recipe.mealType}</p>
            <p><strong>Difficulty:</strong> ${recipe.difficulty}</p>
            ${tagChips ? `<p><strong>Tags:</strong> ${tagChips}</p>` : ""}
            <label>Adjust Servings:
              <select onchange="adjustServings(this, '${ingId}', ${recipe.servings})">
                <option value="1" selected>${recipe.servings} (Default)</option>
                <option value="0.5">Half (${recipe.servings / 2})</option>
                <option value="2">Double (${recipe.servings * 2})</option>
              </select>
            </label>
            <button onclick="toggleSection('${ingId}')">View Ingredients</button>
            <ul id="${ingId}" class="toggle-section" style="display: none;">
              ${ingredientsArray.map(ing => {
                const [amt, unit, ...name] = ing.split(" ");
                return `<li data-original="${amt}">${amt} ${unit} ${name.join(" ")}</li>`;
              }).join("")}
            </ul>
            <button onclick="toggleSection('${fullId}')">View Full Recipe</button>
            <div id="${fullId}" class="toggle-section" style="display: none;">
              <p><strong>Ingredients:</strong></p>
              <ul>${ingredientsArray.map(i => `<li>${i}</li>`).join("")}</ul>
              <p><strong>Instructions:</strong> ${recipe.instructions}</p>
              ${recipe.notes ? `<p><strong>Author's Notes:</strong> ${recipe.notes}</p>` : ""}
            </div>
            <button onclick='editRecipe("${recipe.id}")'>Edit</button>
          </div>
        `;
      }).join("");
  
    } catch (err) {
      console.error("Error loading recipes:", err);
      container.innerHTML = "<p>Error loading recipes. Please try again later.</p>";
    }
  }

function adjustServings(select, recipeId, originalServings) {
    const factor = parseFloat(select.value);
    const ingredients = document.querySelectorAll(`#${recipeId} li`);
    ingredients.forEach(li => {
      const original = parseFloat(li.getAttribute("data-original"));
      if (!isNaN(original)) {
        const parts = li.textContent.split(" ");
        const newAmount = formatFraction(original * factor);
        parts[0] = newAmount;
        li.textContent = parts.join(" ");
      }
    });
  }

  function formatFraction(value) {
    const whole = Math.floor(value);
    const decimal = value - whole;
  
    const fractionMap = {
      0.25: "¼",
      0.33: "⅓",
      0.5: "½",
      0.66: "⅔",
      0.75: "¾"
    };
  
    const closest = Object.keys(fractionMap).reduce((a, b) =>
      Math.abs(decimal - b) < Math.abs(decimal - a) ? b : a
    );
  
    const fraction = fractionMap[closest];
    return decimal === 0 ? whole.toString() :
           whole === 0 ? fraction :
           `${whole}${fraction}`;
  }

          
  
  function clearFilters() {
    document.getElementById("filterMeal").value = "";
    document.getElementById("filterDifficulty").value = "";
    document.getElementById("sortOption").value = "title";
    document.getElementById("sortDirection").value = "asc";
    loadUserRecipes();
  }
  
  async function editRecipe(id) {
    try {
      const response = await fetch(`http://localhost:3000/api/recipes`);
      const recipes = await response.json();
      const recipe = recipes.find(r => r.id === id);
  
      if (!recipe) return;
  
      // Set the existing image path
      const existingImagePath = recipe.image || '';
  
      document.getElementById("editingId").value = recipe.id;
      document.getElementById("recipeTitle").value = recipe.title;
      document.getElementById("recipeServings").value = recipe.servings;
      document.getElementById("recipeMealType").value = recipe.mealType;
      document.getElementById("recipeDifficulty").value = recipe.difficulty;
      document.getElementById("recipeInstructions").value = recipe.instructions;
      document.getElementById("recipeNotes").value = recipe.notes;
      document.getElementById("recipePublic").checked = recipe.isPublic === 1 || recipe.isPublic === true;
  
      // Handle Ingredients
      const container = document.getElementById("ingredientsContainer");
      container.innerHTML = "";
      const ingredientsArray = Array.isArray(recipe.ingredients) ? recipe.ingredients : JSON.parse(recipe.ingredients || "[]");
      ingredientsArray.forEach(ing => {
        const parts = ing.trim().split(" ");
        let amount = "", unit = "", name = "";
        if (parts.length === 1) {
          name = parts[0];
        } else if (parts.length === 2) {
          amount = parts[0];
          name = parts[1];
        } else if (parts.length >= 3) {
          amount = parts[0];
          unit = parts[1];
          name = parts.slice(2).join(" ");
        }
        const row = document.createElement("div");
        row.innerHTML = `
          <input type="text" placeholder="Amount" class="ingredientAmount" value="${amount}" required />
          <input type="text" placeholder="Unit" class="ingredientUnit" value="${unit}" required />
          <input type="text" placeholder="Ingredient Name" class="ingredientName" value="${name}" required />
          <button type="button" onclick="this.parentElement.remove()" class="remove-btn">Remove</button>
        `;
        container.appendChild(row);
      });
  
      // Set tags
      tags.length = 0;
    tagList.innerHTML = "";
    const tagsArray = Array.isArray(recipe.tags) ? recipe.tags : JSON.parse(recipe.tags || "[]");
    tagsArray.forEach(tag => {
      tags.push(tag);
      const li = document.createElement("li");
      li.textContent = `#${tag}`;
      li.onclick = () => {
        tags.splice(tags.indexOf(tag), 1);
        li.remove();
      };
      tagList.appendChild(li);
    });
  
      // Prepare to update image if any
      const formData = new FormData();
      formData.append('existingImage', existingImagePath);
  
      document.getElementById("cancelEditBtn").style.display = "inline-block";
      document.getElementById("recipeFormContainer").style.display = "block";
    } catch (err) {
      console.error("Error editing recipe:", err);
      alert("Failed to load recipe for editing.");
    }
  }
  
  
  function toggleSection(id) {
    const el = document.getElementById(id);
    el.style.display = el.style.display === "none" ? "block" : "none";
  }

  document.getElementById("recipeForm").addEventListener("submit", async function (e) {
    e.preventDefault();
  
    const user = JSON.parse(localStorage.getItem("loggedInUser"));
    if (!user) {
      alert("You must be logged in to save a recipe.");
      return;
    }
  
    const ingredients = [];
    document.querySelectorAll("#ingredientsContainer > div").forEach(row => {
      const amount = row.querySelector(".ingredientAmount")?.value.trim();
      const unit = row.querySelector(".ingredientUnit")?.value.trim();
      const name = row.querySelector(".ingredientName")?.value.trim();
      if (amount && name) {
        ingredients.push(`${amount} ${unit} ${name}`);
      }
    });
  
    const formData = new FormData();
    const editingId = document.getElementById("editingId").value;
  
    formData.append('id', editingId || Date.now().toString());
    formData.append('username', user.username);
    formData.append('title', document.getElementById("recipeTitle").value.trim());
    formData.append('servings', parseInt(document.getElementById("recipeServings").value));
    formData.append('mealType', document.getElementById("recipeMealType").value);
    formData.append('difficulty', document.getElementById("recipeDifficulty").value);
    formData.append('instructions', document.getElementById("recipeInstructions").value.trim());
    formData.append('notes', document.getElementById("recipeNotes").value.trim());
    formData.append('isPublic', document.getElementById("recipePublic").checked ? 1 : 0);
    formData.append('tags', JSON.stringify(tags));
    formData.append('ingredients', JSON.stringify(ingredients));
  
    const imageInput = document.getElementById("recipeImage");
    if (imageInput.files.length > 0) {
      formData.append('image', imageInput.files[0]);
    } else {
      const existingImagePath = document.getElementById("existingImage").value;
      if (existingImagePath) {
        formData.append('existingImage', existingImagePath);
      }
    }
  
    const isEditing = !!editingId;
    const url = isEditing 
      ? `http://localhost:3000/api/recipes/${editingId}` 
      : `http://localhost:3000/api/recipes`;
  
    const method = isEditing ? "PUT" : "POST";
  
    try {
      const response = await fetch(url, {
        method: method,
        body: formData
      });
  
      const data = await response.json();
      if (response.ok) {
        resetForm();
        loadUserRecipes();
        const status = document.getElementById("recipeStatus");
        status.textContent = isEditing ? "Recipe updated successfully!" : "Recipe added successfully!";
        status.style.color = "green";
        setTimeout(() => status.textContent = "", 3000);
      } else {
        throw new Error(data.message);
      }
    } catch (err) {
      console.error("Error saving recipe:", err);
      const status = document.getElementById("recipeStatus");
      status.textContent = "Error saving recipe.";
      status.style.color = "red";
    }
  });
  